package com.cdac.service;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.cdac.dto.Status;

public class FlightServiceFallback implements FlightServiceProxy2 {

	@Override
	public Status isBookingPossible(Map<String, Object> params) {
		return new Status();
	}

	@Override
	public Status blockSeats(Map<String, Object> params) {
		return new Status();
	}

	
}
