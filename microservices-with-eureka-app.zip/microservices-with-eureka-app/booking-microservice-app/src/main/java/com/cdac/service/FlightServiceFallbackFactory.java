package com.cdac.service;

import org.springframework.cloud.openfeign.FallbackFactory;

public class FlightServiceFallbackFactory implements FallbackFactory<FlightServiceProxy2> {
	
	@Override
	public FlightServiceProxy2 create(Throwable cause) {
		System.out.println("checking..");
		return new FlightServiceFallback();
	}

}
